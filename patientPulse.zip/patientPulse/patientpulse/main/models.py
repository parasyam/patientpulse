from django.db import models

class Patient(models.Model):
    patient_name = models.CharField(max_length=150)
    patient_description = models.TextField()  # Fixed the typo

    def __str__(self):
        return self.patient_name